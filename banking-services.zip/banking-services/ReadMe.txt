Technologies Used :
----------------------------------------------------
Java 8, Spring boot, Maven

How to Run ?
--------------------------------------------------
There are tow ways to run

Outside IDE
1. Do mvn clean install going to the root foler banking-services where pom.xml exists. Make sure maven is installed properly in the machine.
2. Execute java -jar target/{Jar name}.jar from the root folder

From IDE
1. Run BankingServicesApplication.java as standalone.

API exposed:
-----------------------------------------------------

POST Request with Json body as {"name":"{name}", "amount":{amount} }- http://localhost:8080/api/v1/bankingServices/createAccount

GET Request for getting account details - http://localhost:8080/api/v1/bankingServices/getAccount/{id}

PUT Request for withdraw - http://localhost:8080/api/v1/bankingServices/withdraw?id={AccountId}&amount={amount}

PUT Request for deposit - http://localhost:8080/api/v1/bankingServices/deposit?id={AccountId}&amount={amount}

PUT Request for transfer - http://localhost:8080/api/v1/bankingServices/transfer?fromAccount={fromAccountId}&toAccount={toAccountId}&amount={amount}
