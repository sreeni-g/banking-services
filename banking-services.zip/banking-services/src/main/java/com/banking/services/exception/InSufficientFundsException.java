/**
 * 
 */
package com.banking.services.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author Sreenivas
 *
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InSufficientFundsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InSufficientFundsException() {
		super();
	}

	public InSufficientFundsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InSufficientFundsException(String message, Throwable cause) {
		super(message, cause);
	}

	public InSufficientFundsException(String message) {
		super(message);
	}

	public InSufficientFundsException(Throwable cause) {
		super(cause);
	}

}
