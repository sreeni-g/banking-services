/**
 * 
 */
package com.banking.services.rest;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.banking.services.model.Account;
import com.banking.services.service.BankingService;

/**
 * @author Sreenivas
 *
 */
@RestController(value = "/bankingServices")
public class BankingServicesController {

	@Autowired
	private BankingService bankingService;

	@PostMapping(value = "/createAccount", produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<Account> createAccount(@RequestBody Account account) {
		return new ResponseEntity<>(bankingService.addAccount(account), HttpStatus.OK);

	}

	@GetMapping(value = "/getAccount/{id}", produces = { "application/json" })
	public ResponseEntity<Account> getAccount(@PathVariable("id") Integer accountId) {
		return new ResponseEntity<>(bankingService.getAccount(accountId), HttpStatus.OK);

	}

	@PutMapping(value = "/withdraw", produces = { "application/json" })
	public ResponseEntity<Account> withDraw(@RequestParam("id") Integer accountId,
			@RequestParam("amount") BigDecimal amount) {
		return new ResponseEntity<>(bankingService.withdrawMoneyFromAccount(accountId, amount), HttpStatus.OK);

	}

	@PutMapping(value = "/deposit", produces = { "application/json" })
	public ResponseEntity<Account> deposite(@RequestParam("id") Integer accountId,
			@RequestParam("amount") BigDecimal amount) {
		return new ResponseEntity<>(bankingService.addMoneyToAccount(accountId, amount), HttpStatus.OK);

	}

	@PutMapping(value = "/transfer", produces = { "application/json" })
	public ResponseEntity<String> transfer(@RequestParam("fromAccount") Integer fromAccount,
			@RequestParam("toAccount") Integer toAccount, @RequestParam("amount") BigDecimal amount) {
		bankingService.transferMoney(fromAccount, toAccount, amount);
		return new ResponseEntity<>("Transferred Successfully", HttpStatus.OK);

	}

}
