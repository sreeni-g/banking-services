package com.banking.services.service;

import java.math.BigDecimal;

import com.banking.services.model.Account;

public interface BankingService {

	Account addAccount(Account account);

	Account getAccount(Integer accountId);

	Account addMoneyToAccount(Integer accountId, BigDecimal amount);

	Account withdrawMoneyFromAccount(Integer accountId, BigDecimal amount);

	void transferMoney(Integer fromAccount, Integer toAccount, BigDecimal amount);

	void removeAllAccounts();

}