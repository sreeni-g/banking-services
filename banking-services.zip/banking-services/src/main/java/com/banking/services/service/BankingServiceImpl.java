package com.banking.services.service;

import static java.text.MessageFormat.format;

import java.math.BigDecimal;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Service;

import com.banking.services.exception.AccountAlreadyExistsException;
import com.banking.services.exception.AccountNotFoundException;
import com.banking.services.exception.InSufficientFundsException;
import com.banking.services.model.Account;

@Service
public class BankingServiceImpl implements BankingService {

	private AtomicInteger currentMaxAccId = new AtomicInteger(0);

	private ConcurrentMap<Integer, Account> accountMap = new ConcurrentHashMap<>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.banking.services.service.BankingService#addAccount(com.banking.services.
	 * model.Account)
	 */
	@Override
	public Account addAccount(Account account) {
		if (verifyAccountExists(account)) {
			throw new AccountAlreadyExistsException(
					format("Account having account name {0} already exists", account.getName()));
		}
		account.setId(currentMaxAccId.incrementAndGet());
		accountMap.put(account.getId(), account);
		return account;
	}

	private boolean verifyAccountExists(Account account) {
		return accountMap.values().stream().anyMatch(acc -> acc.getName().equalsIgnoreCase(account.getName()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.banking.services.service.BankingService#getAccount(java.lang.Integer)
	 */
	@Override
	public Account getAccount(Integer accountId) {
		Account account = accountMap.get(accountId);
		if (account == null) {
			throw new AccountNotFoundException(format("Account having accountId {0} does not exist", accountId));
		}
		return account;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.banking.services.service.BankingService#addMoneyToAccount(java.lang.
	 * Integer, java.math.BigDecimal)
	 */
	@Override
	public Account addMoneyToAccount(Integer accountId, BigDecimal amount) {
		Account account = accountMap.get(accountId);
		account.setAmount(account.getAmount().add(amount));
		return account;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.banking.services.service.BankingService#withdrawMoneyFromAccount(java.
	 * lang.Integer, java.math.BigDecimal)
	 */
	@Override
	public Account withdrawMoneyFromAccount(Integer accountId, BigDecimal amount) {
		Account account = accountMap.get(accountId);
		if (account.getAmount().compareTo(amount) < 0) {
			throw new InSufficientFundsException(
					format("Funds {0} are not availble in acccount {1}", amount.doubleValue(), accountId));
		}
		account.setAmount(account.getAmount().subtract(amount));
		return account;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.banking.services.service.BankingService#transferMoney(java.lang.Integer,
	 * java.lang.Integer, java.math.BigDecimal)
	 */
	@Override
	public void transferMoney(Integer fromAccount, Integer toAccount, BigDecimal amount) {
		withdrawMoneyFromAccount(fromAccount, amount);
		addMoneyToAccount(toAccount, amount);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.banking.services.service.BankingService#removeAllAccounts()
	 */
	@Override
	public void removeAllAccounts() {
		accountMap.clear();
		currentMaxAccId.set(0);
	}

}
