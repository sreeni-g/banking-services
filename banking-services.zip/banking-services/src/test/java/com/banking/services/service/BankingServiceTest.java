package com.banking.services.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.banking.services.BankingServicesApplication;
import com.banking.services.exception.AccountAlreadyExistsException;
import com.banking.services.exception.AccountNotFoundException;
import com.banking.services.exception.InSufficientFundsException;
import com.banking.services.model.Account;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BankingServicesApplication.class)
@WebAppConfiguration
public class BankingServiceTest {

	@Autowired
	private BankingService bankingService;

	@BeforeEach
	public void setup() throws Exception {
		// given
		bankingService.removeAllAccounts();
		Account account = prepareAccount("Sreeni");
		bankingService.addAccount(account);
	}

	private Account prepareAccount(String name) {
		Account account = new Account();
		account.setName(name);
		account.setAmount(BigDecimal.TEN);
		return account;
	}

	@Test
	public void testCreateAccount() {
		// given
		Account account = new Account();
		account.setName("Sree");
		account.setAmount(BigDecimal.TEN);
		// when
		account = bankingService.addAccount(account);
		// then
		assertTrue(account.getId().equals(2));
	}
	
	@Test
	public void testGetAccount() {
		// when
		Account account = bankingService.getAccount(1);
		// then
		assertTrue(account.getId().equals(1));
	}
	
	@Test
	public void testAccountNotFoundExceptionWhenGetAccount() {
		assertThrows(AccountNotFoundException.class, () -> bankingService.getAccount(2));
	}
	
	@Test
	public void testAccountAlreadyExistExceptionWhenCreateAccount() {
		// given
		Account account = new Account();
		account.setName("Sreeni");
		account.setAmount(BigDecimal.TEN);
		//then
		assertThrows(AccountAlreadyExistsException.class, () -> bankingService.addAccount(account));
	}

	@Test
	public void testWithdraw() {
		// when
		Account account = bankingService.withdrawMoneyFromAccount(1, BigDecimal.valueOf(5));
		// then
		assertTrue(account.getAmount().intValue() == 5);
	}
	
	@Test
	public void testInSufficientFundsExceptionWhenWithdraw() throws Exception {
		assertThrows(InSufficientFundsException.class, () -> bankingService.withdrawMoneyFromAccount(1, BigDecimal.valueOf(15)));
	}

	@Test
	public void testDeposit() {
		// when
		Account account = bankingService.addMoneyToAccount(1, BigDecimal.valueOf(5));
		// then
		assertTrue(account.getAmount().intValue() == 15);
	}

}
