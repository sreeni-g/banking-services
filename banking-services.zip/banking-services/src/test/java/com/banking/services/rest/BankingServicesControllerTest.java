package com.banking.services.rest;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.nio.charset.Charset;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.banking.services.BankingServicesApplication;
import com.banking.services.exception.AccountAlreadyExistsException;
import com.banking.services.exception.AccountNotFoundException;
import com.banking.services.exception.InSufficientFundsException;
import com.banking.services.model.Account;
import com.banking.services.service.BankingService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = BankingServicesApplication.class)
@WebAppConfiguration
public class BankingServicesControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Autowired
	private BankingService bankingService;

	private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@BeforeEach
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		this.bankingService.removeAllAccounts();
	}

	@Test
	public void testCreateAccount() throws Exception {
		Account account = new Account();
		account.setName("Sreeni");
		account.setAmount(BigDecimal.TEN);
		final ObjectMapper mapper = new ObjectMapper();

		mockMvc.perform(post("/createAccount").contentType(contentType).content(mapper.writeValueAsString(account)))
				.andExpect(status().isOk());
	}

	@Test
	public void testAccountAlreadyExistsExceptionCreateAccount() throws Exception {
		prepareData("Sreeni");
		Account account = new Account();
		account.setName("Sreeni");
		account.setAmount(BigDecimal.TEN);
		final ObjectMapper mapper = new ObjectMapper();

		MvcResult result = mockMvc
				.perform(post("/createAccount").contentType(contentType).content(mapper.writeValueAsString(account)))
				.andExpect(status().isBadRequest()).andReturn();
		assertTrue(
				result.getResolvedException().getMessage().equals("Account having account name Sreeni already exists"));
		assertTrue(result.getResolvedException().getClass().equals(AccountAlreadyExistsException.class));

	}

	@Test
	public void testGetAccount() throws Exception {
		prepareData("Sreeni");
		mockMvc.perform(get("/getAccount/1")).andExpect(status().isOk()).andExpect(content().contentType(contentType))
				.andExpect(jsonPath("$.name", is("Sreeni")));

	}

	@Test
	public void testInSufficientFundsExceptionWhenWithdraw() throws Exception {
		prepareData("Sreeni");
		MvcResult result = mockMvc.perform(put("/withdraw?id=1&amount=15")).andExpect(status().isBadRequest())
				.andReturn();
		assertTrue(result.getResolvedException().getMessage().equals("Funds 15 are not availble in acccount 1"));
		assertTrue(result.getResolvedException().getClass().equals(InSufficientFundsException.class));
	}

	@Test
	public void testWithdraw() throws Exception {
		prepareData("Sreeni");
		mockMvc.perform(put("/withdraw?id=1&amount=5")).andExpect(status().isOk())
				.andExpect(content().contentType(contentType)).andExpect(jsonPath("$.name", is("Sreeni")))
				.andExpect(jsonPath("$.amount", is(5)));

	}

	@Test
	public void testAccountNotFoundExceptionWhenGetAccount() throws Exception {
		MvcResult result = mockMvc.perform(get("/getAccount/1")).andExpect(status().isBadRequest()).andReturn();
		assertTrue(result.getResolvedException().getMessage().equals("Account having accountId 1 does not exist"));
		assertTrue(result.getResolvedException().getClass().equals(AccountNotFoundException.class));
	}

	@Test
	public void testDeposit() throws Exception {
		prepareData("Sreeni");
		mockMvc.perform(put("/deposit?id=1&amount=5")).andExpect(status().isOk())
				.andExpect(content().contentType(contentType)).andExpect(jsonPath("$.name", is("Sreeni")))
				.andExpect(jsonPath("$.amount", is(15)));

	}

	@Test
	public void testInSufficientFundsExceptionWhentransfer() throws Exception {
		prepareData("Sreeni");
		MvcResult result = mockMvc.perform(put("/transfer?fromAccount=1&toAccount=2&amount=15"))
				.andExpect(status().isBadRequest()).andReturn();
		assertTrue(result.getResolvedException().getMessage().equals("Funds 15 are not availble in acccount 1"));
		assertTrue(result.getResolvedException().getClass().equals(InSufficientFundsException.class));
	}

	@Test
	public void testTransfer() throws Exception {
		prepareData("Sreeni");
		prepareData("Sree");
		mockMvc.perform(put("/transfer?fromAccount=1&toAccount=2&amount=5")).andExpect(status().isOk()).andReturn()
				.equals("Transferred Successfully");

	}

	private void prepareData(String name) {
		Account account = new Account();
		account.setName(name);
		account.setAmount(BigDecimal.TEN);
		bankingService.addAccount(account);
	}
}
